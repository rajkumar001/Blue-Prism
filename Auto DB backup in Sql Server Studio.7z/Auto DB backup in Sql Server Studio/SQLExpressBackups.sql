BACKUP DATABASE Rajkumar TO  DISK = N'D:\DB auto backup\Rajkumar.bak' 
WITH NOFORMAT, INIT,  NAME = N'Rajkumar Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO